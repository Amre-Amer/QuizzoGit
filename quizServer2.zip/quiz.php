<h1>
Quiz
</h1>
<a href=report.php>report</a>
<p>
<a href=reportReplay.php>reportReplay</a>
<p>
<a href=https://drive.google.com/file/d/1IDN75dC_xcCQU6SgMvCFgvKnqbHC6ZoG/view?usp=sharing>video</a>
<p>
<img src=https://drive.google.com/uc?export=view&id=14DUixBE2m-v3oix2IFGaSRRKyiMgotf5>
<hr>
<h3>Reset</h3>
<a href=create.php>create</a>
<p>
<a href=createReplay.php>createReplay</a>
<p>
